
import Foundation
import CoreData

@objc(Team)
public class Team: NSManagedObject {
}
